/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.fin.cutsom.tag.apps;

import java.util.Calendar;
import java.util.Random;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

/**
 *
 * @author ravindra6
 */
public class custom_Tag extends TagSupport{
    
   @Override
   public int doStartTag()throws JspException
   {
       JspWriter jspWriter=pageContext.getOut();
       int st=0,min=1,max=8;
       
       try {
            Random random=new Random();
          
              st=random.nextInt(max);
               jspWriter.print(st);
           
       } catch (Exception e) 
       {
           System.out.println("Message:= "+e.getMessage());
       }
       return SKIP_BODY;
   } 
   
}
